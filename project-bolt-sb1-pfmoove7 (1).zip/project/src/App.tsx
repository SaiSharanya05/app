import React, { useState, useEffect } from 'react';
import { Task, Notification } from './types';
import { loadTasks, saveTasks, loadNotifications, saveNotifications, createNotificationFromTask } from './utils/storage';
import HomeScreen from './components/HomeScreen';
import GanttChart from './components/GanttChart';
import TaskModal from './components/TaskModal';

type Screen = 'home' | 'gantt';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [quickTaskData, setQuickTaskData] = useState<{ date: string; time: string } | null>(null);

  // Load tasks and notifications on component mount
  useEffect(() => {
    const loadedTasks = loadTasks();
    const loadedNotifications = loadNotifications();
    setTasks(loadedTasks);
    setNotifications(loadedNotifications);
  }, []);

  // Save tasks whenever tasks state changes
  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  // Save notifications whenever notifications state changes
  useEffect(() => {
    saveNotifications(notifications);
  }, [notifications]);

  const handleCreateTask = () => {
    setEditingTask(null);
    setQuickTaskData(null);
    setIsTaskModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setQuickTaskData(null);
    setIsTaskModalOpen(true);
  };

  const handleQuickTaskCreate = (date: string, time: string) => {
    setEditingTask(null);
    setQuickTaskData({ date, time });
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = (task: Task) => {
    if (editingTask) {
      // Update existing task
      setTasks(prev => prev.map(t => t.id === task.id ? task : t));
      // Update corresponding notification
      const notification = createNotificationFromTask(task);
      setNotifications(prev => prev.map(n => 
        n.taskId === task.id ? { ...notification, id: n.id, read: n.read } : n
      ));
    } else {
      // Add new task
      let newTask = task;
      if (quickTaskData) {
        // Quick task from Gantt chart
        const endTime = `${(parseInt(quickTaskData.time.split(':')[0]) + 1).toString().padStart(2, '0')}:${quickTaskData.time.split(':')[1]}`;
        newTask = {
          ...task,
          date: quickTaskData.date,
          startTime: quickTaskData.time,
          endTime: endTime
        };
      }
      setTasks(prev => [...prev, newTask]);
      // Create notification for new task
      const notification = createNotificationFromTask(newTask);
      setNotifications(prev => [...prev, notification]);
    }
    setIsTaskModalOpen(false);
    setEditingTask(null);
    setQuickTaskData(null);
  };

  const handleToggleStar = (taskId: string) => {
    setTasks(prev => prev.map(task =>
      task.id === taskId ? { ...task, starred: !task.starred } : task
    ));
  };

  const handleTaskMove = (taskId: string, newDate: string, newStartTime: string) => {
    setTasks(prev => prev.map(task => {
      if (task.id === taskId) {
        const [startHour, startMinute] = task.startTime.split(':').map(Number);
        const [endHour, endMinute] = task.endTime.split(':').map(Number);
        const [newStartHour, newStartMinute] = newStartTime.split(':').map(Number);
        
        const durationMinutes = (endHour * 60 + endMinute) - (startHour * 60 + startMinute);
        const newEndMinutes = (newStartHour * 60 + newStartMinute) + durationMinutes;
        const newEndHour = Math.floor(newEndMinutes / 60);
        const newEndMinute = newEndMinutes % 60;
        
        const newEndTime = `${newEndHour.toString().padStart(2, '0')}:${newEndMinute.toString().padStart(2, '0')}`;
        
        const updatedTask = {
          ...task,
          date: newDate,
          startTime: newStartTime,
          endTime: newEndTime
        };

        // Update corresponding notification
        const notification = createNotificationFromTask(updatedTask);
        setNotifications(prev => prev.map(n => 
          n.taskId === taskId ? { ...notification, id: n.id, read: n.read } : n
        ));

        return updatedTask;
      }
      return task;
    }));
  };

  const handleMarkNotificationAsRead = (notificationId: string) => {
    setNotifications(prev => prev.map(notification =>
      notification.id === notificationId ? { ...notification, read: true } : notification
    ));
  };

  const handleToggleNotificationStar = (notificationId: string) => {
    // This could be implemented to star notifications if needed
    console.log('Toggle notification star:', notificationId);
  };

  const handleOpenClasses = () => {
    setCurrentScreen('gantt');
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
  };

  return (
    <div className="font-sans bg-gray-50">
      {currentScreen === 'home' ? (
        <HomeScreen
          tasks={tasks}
          notifications={notifications}
          onCreateTask={handleCreateTask}
          onOpenClasses={handleOpenClasses}
          onToggleStar={handleToggleStar}
          onMarkNotificationAsRead={handleMarkNotificationAsRead}
          onToggleNotificationStar={handleToggleNotificationStar}
        />
      ) : (
        <GanttChart
          tasks={tasks}
          onBack={handleBackToHome}
          onTaskClick={handleQuickTaskCreate}
          onTaskEdit={handleEditTask}
          onTaskMove={handleTaskMove}
        />
      )}

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setEditingTask(null);
          setQuickTaskData(null);
        }}
        onSave={handleSaveTask}
        editingTask={editingTask}
      />
    </div>
  );
}

export default App;