import React, { useState } from 'react';
import { Plus, Star, Bell, ChevronLeft, ChevronRight } from 'lucide-react';
import { Task, Notification } from '../types';
import { getCurrentDate, formatDateHeader, addDays } from '../utils/dateUtils';
import TaskCard from './TaskCard';
import NotificationPanel from './NotificationPanel';

interface HomeScreenProps {
  tasks: Task[];
  notifications: Notification[];
  onCreateTask: () => void;
  onOpenClasses: () => void;
  onToggleStar: (taskId: string) => void;
  onMarkNotificationAsRead: (notificationId: string) => void;
  onToggleNotificationStar: (notificationId: string) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ 
  tasks, 
  notifications,
  onCreateTask, 
  onOpenClasses, 
  onToggleStar,
  onMarkNotificationAsRead,
  onToggleNotificationStar
}) => {
  const [currentDate, setCurrentDate] = useState(getCurrentDate());
  const [isNotificationPanelOpen, setIsNotificationPanelOpen] = useState(false);
  
  const todayTasks = tasks.filter(task => task.date === currentDate);
  const { dayName, dayNumber } = formatDateHeader(currentDate);

  // Get unread notification count
  const unreadNotificationCount = notifications.filter(notification => !notification.read).length;

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = addDays(currentDate, direction === 'prev' ? -1 : 1);
    setCurrentDate(newDate);
  };

  const isToday = currentDate === getCurrentDate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Status Bar */}
      <div className="bg-white px-4 py-2 flex justify-between items-center text-sm">
        <span className="font-medium">9:41</span>
        <div className="flex items-center space-x-1">
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
          </div>
          <div className="w-6 h-3 bg-green-500 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4">
        {/* Action Buttons */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <button
            onClick={onCreateTask}
            className="bg-blue-500 rounded-2xl p-4 flex flex-col items-center justify-center space-y-2 hover:bg-blue-600 transition-colors"
          >
            <Plus size={24} className="text-white" />
            <span className="text-white text-sm font-medium">TASK/MEETING</span>
          </button>

          <button 
            onClick={() => setIsNotificationPanelOpen(true)}
            className="relative bg-blue-500 rounded-2xl p-4 flex flex-col items-center justify-center space-y-2 hover:bg-blue-600 transition-colors"
          >
            <Bell size={24} className="text-white" />
            {unreadNotificationCount > 0 && (
              <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {unreadNotificationCount}
              </div>
            )}
          </button>

          <button
            onClick={onOpenClasses}
            className="bg-blue-500 rounded-2xl p-4 flex flex-col items-center justify-center space-y-2 hover:bg-blue-600 transition-colors"
          >
            <Star size={24} className="text-white" />
            <span className="text-white text-sm font-medium">CLASSES</span>
          </button>
        </div>

        {/* Date Navigation */}
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => navigateDate('prev')}
            className="p-2 bg-gray-200 rounded-full hover:bg-gray-300 transition-colors"
          >
            <ChevronLeft size={20} className="text-gray-600" />
          </button>
          <div className={`px-4 py-2 rounded-lg ${isToday ? 'bg-blue-500' : 'bg-gray-300'}`}>
            <span className={`text-sm font-medium ${isToday ? 'text-white' : 'text-gray-700'}`}>
              {isToday ? 'TODAY' : `${dayName} ${dayNumber}`}
            </span>
          </div>
          <button 
            onClick={() => navigateDate('next')}
            className="p-2 bg-gray-200 rounded-full hover:bg-gray-300 transition-colors"
          >
            <ChevronRight size={20} className="text-gray-600" />
          </button>
        </div>

        {/* Today's Schedule */}
        <div className="mb-6">
          <h2 className="text-sm text-gray-600 mb-3">upcoming classes ...</h2>
          
          {todayTasks.length > 0 ? (
            <div className="space-y-2">
              {todayTasks
                .sort((a, b) => a.startTime.localeCompare(b.startTime))
                .map(task => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onToggleStar={onToggleStar}
                  />
                ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 text-sm">
                {isToday ? 'No classes scheduled for today' : `No classes scheduled for ${dayName} ${dayNumber}`}
              </p>
              <p className="text-gray-400 text-xs mt-1">Tap the + button to add a new task</p>
            </div>
          )}
        </div>
      </div>

      {/* Notification Panel */}
      <NotificationPanel
        isOpen={isNotificationPanelOpen}
        onClose={() => setIsNotificationPanelOpen(false)}
        notifications={notifications}
        onMarkAsRead={onMarkNotificationAsRead}
        onToggleNotificationStar={onToggleNotificationStar}
      />
    </div>
  );
};

export default HomeScreen;