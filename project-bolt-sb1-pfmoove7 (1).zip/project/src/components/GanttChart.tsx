import React, { useState, useRef, useCallback } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Plus, Edit3 } from 'lucide-react';
import { Task, TimeSlot } from '../types';
import { formatDateHeader, getWeekDates, getMonday, addDays } from '../utils/dateUtils';

interface GanttChartProps {
  tasks: Task[];
  onBack: () => void;
  onTaskClick: (date: string, time: string) => void;
  onTaskEdit: (task: Task) => void;
  onTaskMove: (taskId: string, newDate: string, newStartTime: string) => void;
}

const GanttChart: React.FC<GanttChartProps> = ({ 
  tasks, 
  onBack, 
  onTaskClick, 
  onTaskEdit,
  onTaskMove 
}) => {
  const [currentWeekStart, setCurrentWeekStart] = useState(getMonday(new Date().toISOString().split('T')[0]));
  const [draggedTask, setDraggedTask] = useState<Task | null>(null);
  const [dragOverSlot, setDragOverSlot] = useState<{ date: string; time: string } | null>(null);
  const dragStartPos = useRef<{ x: number; y: number } | null>(null);

  const timeSlots: TimeSlot[] = [];
  for (let hour = 8; hour <= 20; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      timeSlots.push({
        time: `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
        hour,
        minute
      });
    }
  }

  const weekDates = getWeekDates(currentWeekStart);

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newDate = addDays(currentWeekStart, direction === 'prev' ? -7 : 7);
    setCurrentWeekStart(newDate);
  };

  const getTaskAtSlot = (date: string, timeSlot: TimeSlot): Task | null => {
    return tasks.find(task => 
      task.date === date && 
      task.startTime <= timeSlot.time && 
      task.endTime > timeSlot.time
    ) || null;
  };

  const getTaskHeight = (task: Task): number => {
    const [startHour, startMinute] = task.startTime.split(':').map(Number);
    const [endHour, endMinute] = task.endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMinute;
    const endMinutes = endHour * 60 + endMinute;
    const durationMinutes = endMinutes - startMinutes;
    
    return Math.max(1, Math.ceil(durationMinutes / 30));
  };

  const isTaskStart = (task: Task, timeSlot: TimeSlot): boolean => {
    return task.startTime === timeSlot.time;
  };

  const getTaskStyle = (task: Task) => {
    const baseStyle = draggedTask?.id === task.id ? 'opacity-50 ' : '';
    switch (task.type) {
      case 'class':
        return baseStyle + 'bg-yellow-200 border border-yellow-300 text-yellow-800';
      case 'meeting':
        return baseStyle + 'bg-red-200 border border-red-300 text-red-800';
      case 'personal':
        return baseStyle + 'bg-red-200 border border-red-300 text-red-800';
      case 'free':
        return baseStyle + 'bg-gray-200 border border-gray-300 text-gray-700';
      default:
        return baseStyle + 'bg-blue-200 border border-blue-300 text-blue-800';
    }
  };

  const getCurrentMonthYear = () => {
    const date = new Date(currentWeekStart);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  const handleDragStart = useCallback((e: React.DragEvent, task: Task) => {
    setDraggedTask(task);
    dragStartPos.current = { x: e.clientX, y: e.clientY };
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', task.id);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent, date: string, time: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverSlot({ date, time });
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOverSlot(null);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, date: string, time: string) => {
    e.preventDefault();
    if (draggedTask && onTaskMove) {
      onTaskMove(draggedTask.id, date, time);
    }
    setDraggedTask(null);
    setDragOverSlot(null);
    dragStartPos.current = null;
  }, [draggedTask, onTaskMove]);

  const handleDragEnd = useCallback(() => {
    setDraggedTask(null);
    setDragOverSlot(null);
    dragStartPos.current = null;
  }, []);

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Status Bar */}
      <div className="bg-white px-4 py-2 flex justify-between items-center text-sm">
        <span className="font-medium">9:41</span>
        <div className="flex items-center space-x-1">
          <div className="flex space-x-1">
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-black rounded-full"></div>
            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
          </div>
          <div className="w-6 h-3 bg-green-500 rounded-sm ml-2"></div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-white">
        <button onClick={onBack} className="flex items-center text-blue-600">
          <ArrowLeft size={20} className="mr-2" />
          <span className="font-medium">Back</span>
        </button>
        <div className="text-center">
          <h1 className="text-lg font-semibold text-gray-900">Semester Schedule</h1>
        </div>
        <div className="w-16"></div>
      </div>

      {/* Week Navigation */}
      <div className="p-4 border-b bg-gray-50">
        <div className="text-center">
          <h2 className="text-lg font-medium text-blue-600 mb-1">{getCurrentMonthYear()}</h2>
          <p className="text-sm text-gray-600 mb-3">4-Month Semester View • Drag to move, tap to edit</p>
          <div className="flex items-center justify-center space-x-4">
            <button 
              onClick={() => navigateWeek('prev')} 
              className="p-2 hover:bg-gray-200 rounded-full transition-colors"
            >
              <ChevronLeft size={20} className="text-gray-600" />
            </button>
            <span className="text-sm font-medium text-gray-700 min-w-32">
              Week of {new Date(currentWeekStart).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </span>
            <button 
              onClick={() => navigateWeek('next')} 
              className="p-2 hover:bg-gray-200 rounded-full transition-colors"
            >
              <ChevronRight size={20} className="text-gray-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Gantt Chart */}
      <div className="flex-1 overflow-auto">
        <div className="min-w-full">
          {/* Header Row */}
          <div className="sticky top-0 bg-white border-b z-10">
            <div className="grid grid-cols-8 gap-px bg-gray-200">
              <div className="bg-gray-100 p-3 text-center font-medium text-gray-700 text-sm">
                Time
              </div>
              {weekDates.map((date) => {
                const { dayName, dayNumber } = formatDateHeader(date);
                return (
                  <div key={date} className="bg-gray-100 p-3 text-center">
                    <div className="text-sm font-medium text-gray-800">{dayName}</div>
                    <div className="text-xs text-gray-600">{dayNumber}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Time Slots */}
          <div className="grid grid-cols-8 gap-px bg-gray-200">
            {timeSlots.map((timeSlot) => (
              <React.Fragment key={timeSlot.time}>
                {/* Time Label */}
                <div className="bg-white p-3 text-center text-sm text-gray-600 border-r font-medium">
                  {timeSlot.minute === 0 ? `${timeSlot.hour}:00` : ''}
                </div>

                {/* Day Columns */}
                {weekDates.map((date) => {
                  const task = getTaskAtSlot(date, timeSlot);
                  const isStart = task && isTaskStart(task, timeSlot);
                  const isDragOver = dragOverSlot?.date === date && dragOverSlot?.time === timeSlot.time;
                  
                  if (task && !isStart) {
                    return <div key={`${date}-${timeSlot.time}`} className="bg-white"></div>;
                  }

                  return (
                    <div
                      key={`${date}-${timeSlot.time}`}
                      className={`bg-white min-h-[3rem] border-b border-gray-100 relative group ${
                        isDragOver ? 'bg-blue-100 border-blue-300' : ''
                      }`}
                      onDragOver={(e) => handleDragOver(e, date, timeSlot.time)}
                      onDragLeave={handleDragLeave}
                      onDrop={(e) => handleDrop(e, date, timeSlot.time)}
                    >
                      {task && isStart ? (
                        <div
                          draggable
                          onDragStart={(e) => handleDragStart(e, task)}
                          onDragEnd={handleDragEnd}
                          className={`
                            absolute inset-0 p-2 rounded-md text-xs font-medium text-left
                            hover:shadow-lg transition-all cursor-move transform hover:scale-105
                            ${getTaskStyle(task)}
                          `}
                          style={{
                            height: `${getTaskHeight(task) * 3}rem`,
                            zIndex: draggedTask?.id === task.id ? 10 : 1
                          }}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                              <div className="truncate font-semibold">{task.title}</div>
                              {task.room && (
                                <div className="text-xs opacity-80 truncate mt-1">Room {task.room}</div>
                              )}
                              <div className="text-xs opacity-70 mt-1">
                                {task.startTime} - {task.endTime}
                              </div>
                            </div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onTaskEdit(task);
                              }}
                              className="p-1 hover:bg-white hover:bg-opacity-50 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Edit3 size={12} />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => onTaskClick(date, timeSlot.time)}
                          className="absolute inset-0 hover:bg-blue-50 hover:border-blue-200 border border-transparent transition-all group-hover:shadow-sm"
                          title="Click to add task"
                        >
                          <div className="hidden group-hover:flex items-center justify-center h-full">
                            <Plus size={16} className="text-blue-600" />
                          </div>
                        </button>
                      )}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GanttChart;