import React, { useState, useEffect } from 'react';
import { ArrowLeft, Star } from 'lucide-react';
import { Task } from '../types';
import { generateId } from '../utils/storage';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Task) => void;
  editingTask?: Task | null;
}

const TaskModal: React.FC<TaskModalProps> = ({ isOpen, onClose, onSave, editingTask }) => {
  const [taskName, setTaskName] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [room, setRoom] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [starred, setStarred] = useState(false);

  // Reset form when modal opens/closes or editing task changes
  useEffect(() => {
    if (isOpen) {
      if (editingTask) {
        setTaskName(editingTask.title);
        setSelectedDate(editingTask.date);
        setStartTime(editingTask.startTime);
        setEndTime(editingTask.endTime);
        setRoom(editingTask.room || '');
        setPriority(editingTask.priority);
        setStarred(editingTask.starred);
      } else {
        setTaskName('');
        setSelectedDate(new Date().toISOString().split('T')[0]);
        setStartTime('09:00');
        setEndTime('10:00');
        setRoom('');
        setPriority('medium');
        setStarred(false);
      }
    }
  }, [isOpen, editingTask]);

  const getCurrentMonthYear = () => {
    const date = new Date(selectedDate);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  const generateCalendar = () => {
    const date = new Date(selectedDate);
    const year = date.getFullYear();
    const month = date.getMonth();
    
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysInPrevMonth = new Date(year, month, 0).getDate();
    
    const calendar = [];
    
    // Previous month's trailing days
    for (let i = firstDay - 1; i >= 0; i--) {
      calendar.push({
        day: daysInPrevMonth - i,
        isCurrentMonth: false,
        date: new Date(year, month - 1, daysInPrevMonth - i).toISOString().split('T')[0]
      });
    }
    
    // Current month's days
    for (let day = 1; day <= daysInMonth; day++) {
      calendar.push({
        day,
        isCurrentMonth: true,
        date: new Date(year, month, day).toISOString().split('T')[0]
      });
    }
    
    // Next month's leading days
    const remainingSlots = 42 - calendar.length;
    for (let day = 1; day <= remainingSlots; day++) {
      calendar.push({
        day,
        isCurrentMonth: false,
        date: new Date(year, month + 1, day).toISOString().split('T')[0]
      });
    }
    
    return calendar;
  };

  const handleSave = () => {
    if (!taskName.trim()) return;

    const task: Task = {
      id: editingTask?.id || generateId(),
      title: taskName,
      date: selectedDate,
      startTime,
      endTime,
      room: room.trim(),
      type: 'meeting',
      priority,
      starred,
      createdAt: editingTask?.createdAt || new Date().toISOString()
    };

    onSave(task);
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const date = new Date(selectedDate);
    if (direction === 'prev') {
      date.setMonth(date.getMonth() - 1);
    } else {
      date.setMonth(date.getMonth() + 1);
    }
    setSelectedDate(date.toISOString().split('T')[0]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
      <div className="bg-white rounded-t-3xl w-full max-w-sm mx-auto max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white rounded-t-3xl">
          <button onClick={onClose} className="flex items-center text-blue-600">
            <ArrowLeft size={20} className="mr-2" />
            <span className="font-medium">Back</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-6">
          <div>
            <h2 className="text-lg font-semibold mb-1">
              {editingTask ? 'Edit Meeting/Task' : 'Create a new Meeting/Task'}
            </h2>
            <p className="text-sm text-gray-600 mb-3">Task Name /Meeting</p>
            <input
              type="text"
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
              placeholder="Meeting name"
              className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
            />
          </div>

          {/* Calendar */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <button 
                onClick={() => navigateMonth('prev')} 
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <span className="text-xl text-gray-600">‹</span>
              </button>
              <h3 className="font-semibold text-lg">{getCurrentMonthYear()}</h3>
              <button 
                onClick={() => navigateMonth('next')} 
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <span className="text-xl text-gray-600">›</span>
              </button>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-2">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
                  {day}
                </div>
              ))}
            </div>

            <div className="grid grid-cols-7 gap-1">
              {generateCalendar().map((day, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedDate(day.date)}
                  className={`
                    aspect-square flex items-center justify-center text-sm rounded-lg transition-colors
                    ${day.isCurrentMonth 
                      ? (selectedDate === day.date 
                          ? 'bg-blue-600 text-white' 
                          : 'hover:bg-gray-100 text-gray-900'
                        )
                      : 'text-gray-300'
                    }
                  `}
                >
                  {day.day}
                </button>
              ))}
            </div>
          </div>

          {/* Time Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">End Time</label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
              />
            </div>
          </div>

          {/* Room */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Room No:</label>
            <input
              type="text"
              value={room}
              onChange={(e) => setRoom(e.target.value)}
              placeholder="Enter room number"
              className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-base"
            />
          </div>

          {/* Priority */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">Importance</label>
            <div className="flex gap-6">
              <button
                onClick={() => setPriority('medium')}
                className={`p-3 rounded-full transition-colors ${priority === 'medium' ? 'bg-green-100' : 'hover:bg-gray-100'}`}
              >
                <Star size={28} className={`${priority === 'medium' ? 'fill-green-500 text-green-500' : 'text-gray-400'}`} />
              </button>
              <button
                onClick={() => setPriority('high')}
                className={`p-3 rounded-full transition-colors ${priority === 'high' ? 'bg-red-100' : 'hover:bg-gray-100'}`}
              >
                <Star size={28} className={`${priority === 'high' ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-4 border-t bg-white sticky bottom-0">
          <button
            onClick={onClose}
            className="flex-1 py-4 px-4 text-gray-600 bg-gray-100 rounded-lg font-medium text-base"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!taskName.trim()}
            className="flex-1 py-4 px-4 bg-blue-600 text-white rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed text-base"
          >
            {editingTask ? 'Update' : 'Create'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskModal;