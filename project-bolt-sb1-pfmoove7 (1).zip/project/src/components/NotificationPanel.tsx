import React, { useState } from 'react';
import { ArrowLeft, Star, Clock, MapPin } from 'lucide-react';
import { Notification } from '../types';
import { formatTime } from '../utils/dateUtils';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onMarkAsRead: (notificationId: string) => void;
  onToggleNotificationStar: (notificationId: string) => void;
}

const NotificationPanel: React.FC<NotificationPanelProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAsRead,
  onToggleNotificationStar
}) => {
  const [activeTab, setActiveTab] = useState<'recent' | 'archived'>('recent');

  if (!isOpen) return null;

  const now = new Date();
  const today = now.toISOString().split('T')[0];
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const recentNotifications = notifications.filter(notification => 
    notification.date >= yesterday
  );

  const archivedNotifications = notifications.filter(notification => 
    notification.date < yesterday
  );

  const currentNotifications = activeTab === 'recent' ? recentNotifications : archivedNotifications;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'upcoming':
        return <Clock size={16} className="text-blue-500" />;
      case 'reminder':
        return <Star size={16} className="text-yellow-500" />;
      default:
        return <Clock size={16} className="text-gray-500" />;
    }
  };

  const formatNotificationDate = (date: string) => {
    if (date === today) return 'Today';
    if (date === yesterday) return 'Yesterday';
    return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
      <div className="bg-white rounded-t-3xl w-full max-w-sm mx-auto max-h-[90vh] overflow-hidden">
        {/* Status Bar */}
        <div className="bg-white px-4 py-2 flex justify-between items-center text-sm rounded-t-3xl">
          <span className="font-medium">9:41</span>
          <div className="flex items-center space-x-1">
            <div className="flex space-x-1">
              <div className="w-1 h-1 bg-black rounded-full"></div>
              <div className="w-1 h-1 bg-black rounded-full"></div>
              <div className="w-1 h-1 bg-black rounded-full"></div>
              <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
            </div>
            <div className="w-6 h-3 bg-green-500 rounded-sm ml-2"></div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <button onClick={onClose} className="flex items-center text-blue-600">
            <ArrowLeft size={20} className="mr-2" />
            <span className="font-medium">Back</span>
          </button>
          <h1 className="text-lg font-semibold">Notifications</h1>
          <div className="w-16"></div>
        </div>

        {/* Tabs */}
        <div className="flex border-b">
          <button
            onClick={() => setActiveTab('recent')}
            className={`flex-1 py-3 px-4 text-sm font-medium ${
              activeTab === 'recent'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500'
            }`}
          >
            Recent ({recentNotifications.length})
          </button>
          <button
            onClick={() => setActiveTab('archived')}
            className={`flex-1 py-3 px-4 text-sm font-medium ${
              activeTab === 'archived'
                ? 'text-blue-600 border-b-2 border-blue-600'
                : 'text-gray-500'
            }`}
          >
            Archived ({archivedNotifications.length})
          </button>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto">
          {currentNotifications.length > 0 ? (
            <div className="p-4 space-y-3">
              {currentNotifications.map(notification => (
                <div
                  key={notification.id}
                  className={`p-4 rounded-lg border ${
                    notification.read ? 'bg-gray-50 border-gray-200' : 'bg-white border-blue-200'
                  }`}
                  onClick={() => !notification.read && onMarkAsRead(notification.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        {getNotificationIcon(notification.type)}
                        <span className="text-xs text-gray-500">
                          {formatNotificationDate(notification.date)}
                        </span>
                        {!notification.read && (
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        )}
                      </div>
                      <h3 className="font-medium text-gray-900 text-sm mb-1">
                        {notification.title}
                      </h3>
                      <p className="text-xs text-gray-600 mb-2">
                        {notification.message}
                      </p>
                      <div className="flex items-center space-x-3 text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Clock size={12} />
                          <span>{formatTime(notification.time)}</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleNotificationStar(notification.id);
                      }}
                      className="p-1 hover:bg-gray-100 rounded"
                    >
                      <Star 
                        size={16} 
                        className="text-gray-400 hover:text-yellow-400" 
                      />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <Clock size={24} className="text-gray-400" />
              </div>
              <p className="text-gray-500 text-sm">
                No {activeTab} notifications
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotificationPanel;