import { Task, Notification } from '../types';

const TASKS_STORAGE_KEY = 'scheduler_tasks';
const NOTIFICATIONS_STORAGE_KEY = 'scheduler_notifications';

export const saveTasks = (tasks: Task[]): void => {
  try {
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
  } catch (error) {
    console.error('Failed to save tasks:', error);
  }
};

export const loadTasks = (): Task[] => {
  try {
    const stored = localStorage.getItem(TASKS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Failed to load tasks:', error);
    return [];
  }
};

export const saveNotifications = (notifications: Notification[]): void => {
  try {
    localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(notifications));
  } catch (error) {
    console.error('Failed to save notifications:', error);
  }
};

export const loadNotifications = (): Notification[] => {
  try {
    const stored = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Failed to load notifications:', error);
    return [];
  }
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const createNotificationFromTask = (task: Task): Notification => {
  return {
    id: generateId(),
    taskId: task.id,
    title: task.title,
    message: `${task.type === 'class' ? 'Class' : 'Meeting'} scheduled${task.room ? ` in Room ${task.room}` : ''}`,
    date: task.date,
    time: task.startTime,
    type: 'upcoming',
    read: false,
    createdAt: new Date().toISOString()
  };
};