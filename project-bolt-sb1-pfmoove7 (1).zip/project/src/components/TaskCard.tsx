import React from 'react';
import { Task } from '../types';
import { formatTimeRange } from '../utils/dateUtils';
import { Star, ChevronRight } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onToggleStar: (taskId: string) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onToggleStar }) => {
  const getCardStyle = () => {
    switch (task.type) {
      case 'class':
        return 'bg-yellow-100 border-l-4 border-yellow-500';
      case 'meeting':
        return 'bg-red-100 border-l-4 border-red-500';
      case 'personal':
        return 'bg-red-100 border-l-4 border-red-500';
      case 'free':
        return 'bg-gray-100 border-l-4 border-gray-400';
      default:
        return 'bg-blue-100 border-l-4 border-blue-500';
    }
  };

  const getTimeColor = () => {
    switch (task.type) {
      case 'class':
        return 'text-yellow-700';
      case 'meeting':
      case 'personal':
        return 'text-red-700';
      case 'free':
        return 'text-gray-600';
      default:
        return 'text-blue-700';
    }
  };

  return (
    <div className={`p-4 rounded-lg mb-2 shadow-sm ${getCardStyle()}`}>
      <div className="flex justify-between items-center">
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 text-base mb-1">
            {task.title}
          </h3>
          {task.room && (
            <p className="text-sm text-gray-600 mb-2">
              ROOM NO: {task.room}
            </p>
          )}
          <p className={`text-sm font-medium ${getTimeColor()}`}>
            {formatTimeRange(task.startTime, task.endTime)}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onToggleStar(task.id)}
            className="p-2 hover:bg-white hover:bg-opacity-50 rounded-full transition-colors"
          >
            <Star 
              size={18} 
              className={task.starred ? 'fill-yellow-400 text-yellow-400' : 'text-gray-400'} 
            />
          </button>
          <ChevronRight size={16} className="text-gray-400" />
        </div>
      </div>
    </div>
  );
};

export default TaskCard;