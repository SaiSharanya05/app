export interface Task {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  room?: string;
  type: 'class' | 'meeting' | 'personal' | 'free';
  priority: 'low' | 'medium' | 'high';
  starred: boolean;
  createdAt: string;
}

export interface TimeSlot {
  time: string;
  hour: number;
  minute: number;
}

export interface DayColumn {
  date: string;
  dayName: string;
  dayNumber: number;
}

export interface Notification {
  id: string;
  taskId: string;
  title: string;
  message: string;
  date: string;
  time: string;
  type: 'upcoming' | 'reminder' | 'completed';
  read: boolean;
  createdAt: string;
}